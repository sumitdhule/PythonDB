#!C:\Users\sumit\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("content-type:text/html")
print()

try:
    reqobj=cgi.FieldStorage()
    id=reqobj.getvalue("uid")
    nm=reqobj.getvalue("modnm")
    comnm=reqobj.getvalue("com")
    conn=reqobj.getvalue("conn")
    ram=reqobj.getvalue("ram")
    rom=reqobj.getvalue("rom")
    color=reqobj.getvalue("col")
    scr=reqobj.getvalue("scr")
    bat=reqobj.getvalue("bat")
    proc=reqobj.getvalue("proc")
    price=reqobj.getvalue("pri")
    rat=reqobj.getvalue("rat")

    #print(id+ps+nm+gn+ct+mo+em)
    con=pymysql.connect(host='byysj7ajhlenbm2nng29-mysql.services.clever-cloud.com',user='upfzeqzqbzwqb3rr',password='nZHCrknifJzOTqbu3MQW',database='byysj7ajhlenbm2nng29')
    curs=con.cursor()
    curs.execute("insert into MOBILES values('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')" %(id,nm,comnm,conn,ram,rom,color,scr,bat,proc,price,rat))
    con.commit()
    print('<h2>Add mobile successfully</h2><hr>')
    print("<a href='01form.html'>Home</a>")
    print("<br><a href='04showmobdata.py'>list of all mobiles</a>")
except Exception as e:
    print('error',e)
