#!C:\Users\sumit\AppData\Local\Programs\Python\Python310\python

from tkinter.ttk import Style
import pymysql

print("content-type:text/html")
print()
print("<body style='background-color:violet'>")
print("<link rel='stylesheet' href='bootstrap.min.css'>")
print("<div class='container'>")

con=pymysql.connect(host='byysj7ajhlenbm2nng29-mysql.services.clever-cloud.com',user='upfzeqzqbzwqb3rr',password='nZHCrknifJzOTqbu3MQW',database='byysj7ajhlenbm2nng29')
curs=con.cursor()
curs.execute("select * from MOBILES")
data=curs.fetchall()
#print("<h2 class='display-4' style='color:green;'><b>Mobiles List</b></h2><hr>")
print("<h2 class='display-4' style='text-align:center;' style='color:green;'><b>Mobiles List</b></h2>")
#print(data)



print("<table class='table table-bordered-color:green'>")
print("<tr style='background-color:pink'>")
print("<th style='color:black;'>Product Id")
print("<th style='color:black;'>Model Name")
print("<th style='color:black;'>Company")
print("<th style='color:black;'>connectivity")
print("<th style='color:black;'>Ram")
print("<th style='color:black;'>Rom")
print("<th style='color:black;'>Color")
print("<th style='color:black;'>Screen")
print("<th style='color:black;'>Battery")
print("<th style='color:black;'>Processor")
print("<th style='color:black;'>Price")
print("<th style='color:black;'>Ratings")
print("</tr>")

for rec in data:
    print("<tr>")
    print("<td style='color:blue;'>",rec[0])
    print("<td style='color:blue;'>",rec[1])
    print("<td style='color:blue;'>",rec[2])
    print("<td style='color:blue;'>",rec[3])
    print("<td style='color:blue;'>",rec[4])
    print("<td style='color:blue;'>",rec[5])
    print("<td style='color:blue;'>",rec[6])
    print("<td style='color:blue;'>",rec[7])
    print("<td style='color:blue;'>",rec[8])
    print("<td style='color:blue;'>",rec[9])
    print("<td style='color:blue;'>",rec[10])
    print("<td style='color:blue;'>",rec[11])
    print("</tr>")

print("</table>")
print("<a href='01form.html'>Home</a>")
print("</div>")
print("</body>")

con.close()