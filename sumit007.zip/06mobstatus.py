#!C:\Users\sumit\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("content-type:text/html")
print()

reqobj=cgi.FieldStorage()
id=reqobj.getvalue("uid")

con=pymysql.connect(host='byysj7ajhlenbm2nng29-mysql.services.clever-cloud.com',user='upfzeqzqbzwqb3rr',password='nZHCrknifJzOTqbu3MQW',database='byysj7ajhlenbm2nng29')
curs=con.cursor()

curs.execute("select * from MOBILES" %id)
data=curs.fetchone()

if data:
    print("<span style='color:red'>Sorry! this userid is already taken</span>")
else:
    print("<span style='color:green'>Congrats! userid %s is available" %id)

con.close()