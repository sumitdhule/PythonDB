#!C:\Users\sumit\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("<link rel='stylesheet' href='bootstrap.min.css'>")
print("<div class='container'>")

print("content-type:text/html")
print()

reqobj=cgi.FieldStorage()
nm=reqobj.getvalue("nm")


con=pymysql.connect(host='byysj7ajhlenbm2nng29-mysql.services.clever-cloud.com',user='upfzeqzqbzwqb3rr',password='nZHCrknifJzOTqbu3MQW',database='byysj7ajhlenbm2nng29')
curs=con.cursor()

curs.execute("select * from MOBILES where COMPANY='%s'" %nm)
data=curs.fetchone()
#print(data)

if data:
    print("PRODID:",data[0])
    print("<br>COMNM:",data[1])
else:
    print('Mobile not exist')

con.close()