#!C:\Users\sumit\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("content-type:text/html")
print()
print("<body style='background-color:pink'>")
print("<link rel='stylesheet' href='bootstrap.min.css'>")
print("<div class='container'>")

reqobj=cgi.FieldStorage()
uid=int(reqobj.getvalue("uid"))
con=pymysql.connect(host='byysj7ajhlenbm2nng29-mysql.services.clever-cloud.com',user='upfzeqzqbzwqb3rr',password='nZHCrknifJzOTqbu3MQW',database='byysj7ajhlenbm2nng29')
curs=con.cursor()

curs.execute("delete from MOBILES where PRODID='%d'"%uid)

con.commit()
print('Mobile deleted susseccfully')
print("<br><a href='01form.html'>Home</a>")
con.close()
