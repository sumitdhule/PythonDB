#!C:\Users\sumit\AppData\Local\Programs\Python\Python310\python
import cgi
import pymysql

print("<link rel='stylesheet' href='bootstrap.min.css'>")
print("<div class='container'>")

print("content-type:text/html")
print()

reqobj=cgi.FieldStorage()
uid=int(reqobj.getvalue("uid"))
np=reqobj.getvalue("np")
con=pymysql.connect(host='byysj7ajhlenbm2nng29-mysql.services.clever-cloud.com',user='upfzeqzqbzwqb3rr',password='nZHCrknifJzOTqbu3MQW',database='byysj7ajhlenbm2nng29')
curs=con.cursor()

curs.execute("select * from MOBILES where PRODID='%d'"%uid)
data=curs.fetchall()
print(data)

if data:
    curs.execute("update MOBILES set PRICE='%s'where PRODID='%d';"%(np,uid))
    con.commit()
    #print(data)
else:
    print('Mobile not exist')

con.close()
