import pymysql

print("content-type:text/html")
print()

print("<link rel='stylesheet' href='bootstrap.min.css'>")
print("<div class='container'>")

con=pymysql.connect(host='byysj7ajhlenbm2nng29-mysql.services.clever-cloud.com',user='upfzeqzqbzwqb3rr',password='nZHCrknifJzOTqbu3MQW',database='byysj7ajhlenbm2nng29')
curs=con.cursor()
curs.execute("select * from MOBILES")
data=curs.fetchall()

print("<br><br><h2 class='display-4'>Mobile List</h2><hr>")
#print(data)

print("<table class='table table-bordered table-hover'>")
print("<tr style='background-color:azure'>")
print("<th>Number")
print("<th>Name")
print("<th>Type")
print("<th>Balance")
print("</tr>")

for rec in data:
    print("<tr>")
    print("<td>",rec[0])
    print("<td>",rec[1])
    print("<td>",rec[2])
    print("<td>",rec[3])
    print("</tr>")

print("</table>")

print("<br><a href='03Admin.html'>Home</a>")
print("</div>")
con.close()

